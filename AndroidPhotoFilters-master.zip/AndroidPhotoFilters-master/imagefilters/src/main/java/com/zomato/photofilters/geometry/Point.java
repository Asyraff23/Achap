package com.zomato.photofilters.geometry;

/**
 * @author Varun on 29/06/15.
 */
public class Point {
    public float x;
    public float y;

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
